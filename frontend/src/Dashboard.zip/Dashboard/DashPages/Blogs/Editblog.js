import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, Link } from 'react-router-dom';
import NavDash from '../NavDash';
import DashFoot from '../DashFoot';

const EditBlog = () => {
    const initialFormData = {
        image: '',
        heading: '',
        description: ''
    };

    const [formData, setFormData] = useState(initialFormData);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [success, setSuccess] = useState(false);
    const { id } = useParams();

    useEffect(() => {
        const fetchNewsItem = async () => {
            try {
                const response = await axios.get(`http://localhost:5000/blog/${id}`);
                const { image, heading, description } = response.data;
                setFormData({ image, heading, description });
            } catch (error) {
                console.error('Error fetching blog:', error);
                setError('Failed to fetch data');
            }
        };

        fetchNewsItem();
    }, [id]);

    const handleChange = (e) => {
        if (e.target.type === 'file') {
            const file = e.target.files[0];
            setFormData({ ...formData, image: file });
        } else {
            setFormData({ ...formData, [e.target.name]: e.target.value });
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError(null);

        try {
            const formDataWithFile = new FormData();
            formDataWithFile.append('image', formData.image);
            formDataWithFile.append('heading', formData.heading);
            formDataWithFile.append('description', formData.description);

            await axios.put(`http://localhost:5000/blog/${id}`, formDataWithFile, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            });
            setSuccess(true);
            setFormData(initialFormData); // Reset form data
        } catch (error) {
            setError('Failed to update the blog');
        } finally {
            setLoading(false);
        }
    };

    return (
        <>
            <NavDash />
            <div className="mt-5 pt-4 mb-5 pb-4">
                <div className="bg-light py-3 px-3">
                    <div className="container d-flex justify-content-between">
                        <h5 className='mb-0'>Edit Blog</h5>
                        <Link to='/blogs' className="btn btn-warning btn-sm">All Blogs</Link>
                    </div>
                </div>
                <div className="col-lg-6 mx-auto bg-success-subtle p-3 p-md-5 mt-4">
                    <form onSubmit={handleSubmit}>
                        <h4>Edit Blog</h4>
                        <div className='mb-3'>
                            <label htmlFor="image">Image:</label>
                            {formData.image && typeof formData.image === 'string' && (
                                <div>
                                    <img
                                        src={`/blogimg/${formData.image}`}
                                        alt="Current Blog"
                                        style={{ width: '50px', height: '50px', objectFit: 'cover', marginBottom: '10px' }}
                                    />
                                </div>
                            )}
                            <input className='form-control' type="file" id="image" name="image" onChange={handleChange} accept="image/*" />
                        </div>
                        <div className='mb-3'>
                            <label htmlFor="heading">Heading:</label>
                            <input className='form-control' type="text" id="heading" name="heading" value={formData.heading} onChange={handleChange} required />
                        </div>
                        <div className='mb-3'>
                            <label htmlFor="description">Description:</label>
                            <input className='form-control' type='text' id="description" name="description" value={formData.description} onChange={handleChange} required />
                        </div>
                        <button type="submit" className="btn btn-success rounded-0 mt-3" disabled={loading}>
                            {loading ? 'Updating...' : 'Update'}
                        </button>
                        {success && <p className="text-success mt-3">Blog updated successfully!</p>}
                        {error && <p className="text-danger mt-3">{error}</p>}
                    </form>
                </div>
            </div>

            <DashFoot />
        </>
    );
};

export default EditBlog;
