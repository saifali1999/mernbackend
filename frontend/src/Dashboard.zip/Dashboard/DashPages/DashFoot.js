import React from 'react'
import '../dashboard.css'
const DashFoot = () => {
  return (
    <div>
        <footer className="text-white fixed-bottom d-flex flex-wrap justify-content-center align-items-center  py-2 mt-4 ">
            <div className="container d-flex align-items-center justify-content-center">
           
            <span className=" mb-md-0 ">© 2024 | All rights reserved.</span>
            </div>
          
        </footer>
    </div>
  )
}

export default DashFoot