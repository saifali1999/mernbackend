import React from 'react'
import { Link } from 'react-router-dom'

const NavDash = () => {
  return (
    <div className='dashboard_nav'>
         <nav className="navbar bg-dark navbar-dark fixed-top">
        <div className="container">
          <Link className="navbar-brand" to="/dashboard">
           <h3> StartIP</h3>
          </Link>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="offcanvas"
            data-bs-target="#offcanvasNavbar"
            aria-controls="offcanvasNavbar"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div
            className="offcanvas offcanvas-end"
            tabIndex="-1"
            id="offcanvasNavbar"
            aria-labelledby="offcanvasNavbarLabel"
          >
            <div className="offcanvas-header">
              <h5 className="offcanvas-title" id="offcanvasNavbarLabel">
                StartIP
              </h5>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="offcanvas"
                aria-label="Close"
              ></button>
            </div>
            <div className="offcanvas-body">
              <ul className="navbar-nav justify-content-end flex-grow-1 ">
                <li className="nav-item mb-2">
                  <Link to='/dashboard' className="nav-link active" aria-current="page" >
                    Dashboard
                  </Link>
                </li>
                <li className="nav-item mb-2">
                  <Link to='/about-us' className="nav-link " aria-current="page" >
                    About Us
                  </Link>
                </li>
                <li className="nav-item mb-2">
                  <Link to='/blogs' className="nav-link " aria-current="page" >
                    Blogs
                  </Link>
                </li>
                <li className="nav-item mb-2">
                  <Link to='/work' className="nav-link " aria-current="page" >
                    Our Work
                  </Link>
                </li>
                <li className="nav-item mb-2">
                  <Link to='/services' className="nav-link " aria-current="page" >
                    Services
                  </Link>
                </li>
                <li className="nav-item mb-2">
                  <Link to='/team' className="nav-link " aria-current="page" >
                    Team
                  </Link>
                </li>

                {/* <li className="nav-item dropdown">
                  <Link
                    className="nav-link dropdown-toggle"
                    href="#"
                    role="button"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                  >
                    Blog
                  </Link>
                  <ul className="dropdown-menu">
                    <li>
                      <Link className="dropdown-item" href="#">
                        Add Blog
                      </Link>
                    </li>
                    <li>
                      <Link className="dropdown-item" href="#">
                        Edit Blog
                      </Link>
                    </li>
                    <li>
                      <Link className="dropdown-item" href="#">
                        Remove Blog
                      </Link>
                    </li>
                  </ul>
                </li> */}
              </ul>
              <div className="btn btn-danger mt-3 rounded-0">Logout</div>
            </div>
          </div>
        </div>
      </nav>
    </div>
  )
}

export default NavDash