import React, { useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import NavDash from '../NavDash';
import DashFoot from '../DashFoot';

const AddWork = () => {
    const [image, setImage] = useState('');
    const [imagePreview, setImagePreview] = useState('');
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [successMessage, setSuccessMessage] = useState('');
    const [errorMessage, setErrorMessage] = useState('');

    const handleImageChange = (e) => {
        const file = e.target.files[0];
        setImage(file);
        setImagePreview(URL.createObjectURL(file));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            const formData = new FormData();
            formData.append('image', image);
            formData.append('title', title);
            formData.append('description', description);

            await axios.post('http://localhost:5000/work', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            });

            setSuccessMessage('New Work Created Successfully!');
            setErrorMessage(''); // Clear any previous error message

            // Reset form fields after successful submission
            setImage('');
            setImagePreview('');
            setTitle('');
            setDescription('');
            e.target.reset(); // Reset form fields

            // Hide success message after 5 seconds
            setTimeout(() => {
                setSuccessMessage('');
            }, 5000);
        } catch (error) {
            setErrorMessage('Error creating work item. Please try again.');
            setSuccessMessage(''); // Clear any previous success message

            // Hide error message after 5 seconds
            setTimeout(() => {
                setErrorMessage('');
            }, 5000);
        }
    };

    return (
        <>
            <NavDash />

            <div className=' mt-5 pt-4  mb-5 pb-4'>
                <div className="bg-light py-3">
                    <div className="container d-flex justify-content-between">
                        <h4 className='mb-0'>Add Work</h4>
                        <Link to='/work' className="btn btn-warning btn-sm">All Works</Link>
                    </div>
                </div>
                <div className='col-lg-6 col-md-7 col-10 mx-auto bg-success-subtle p-5 mt-4'>
                    <form onSubmit={handleSubmit}>
                        <h2 className='mb-3'>Fill Form</h2>
                        <div className="mb-3">
                            <label htmlFor="image" className="form-label">Image</label>
                            {imagePreview && (
                               <div>
                                 <img
                                    src={imagePreview}
                                    alt="Preview"
                                    style={{ width: '70px', height: '70px', objectFit: 'cover', marginBottom: '15px'}}
                                />
                                 </div>
                            )}
                            <input
                                className='form-control'
                                type="file"
                                id="image"
                                onChange={handleImageChange}
                                accept="image/*"
                                required
                            />
                          
                        </div>
                        <div className="mb-3">
                            <label htmlFor="title" className="form-label">Title</label>
                            <input
                                className='form-control'
                                type="text"
                                id="title"
                                value={title}
                                onChange={(e) => setTitle(e.target.value)}
                                required
                            />
                        </div>
                        <div className="mb-3">
                            <label htmlFor="description" className="form-label">Description</label>
                            <input
                                className='form-control'
                                type="text"
                                id="description"
                                value={description}
                                onChange={(e) => setDescription(e.target.value)}
                                required
                            />
                        </div>
                        <button type="submit" className="btn btn-success rounded-0 mt-3">Submit</button>
                        {successMessage && <div className="alert alert-success mt-3">{successMessage}</div>}
                        {errorMessage && <div className="alert alert-danger mt-3">{errorMessage}</div>}
                    </form>
                </div>
            </div>

            <DashFoot />
        </>
    );
};

export default AddWork;
