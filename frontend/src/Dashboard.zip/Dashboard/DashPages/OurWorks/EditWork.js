import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link, useParams } from 'react-router-dom';
import NavDash from '../NavDash';
import DashFoot from '../DashFoot';

const EditWork = () => {
    const initialFormData = {
        image: '',
        title: '',
        description: ''
    };

    const [formData, setFormData] = useState(initialFormData);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [success, setSuccess] = useState(false);
    const { id } = useParams();

    useEffect(() => {
        const fetchWorkItem = async () => {
            try {
                const response = await axios.get(`http://localhost:5000/work/${id}`);
                const { image, title, description } = response.data;
                setFormData({ image, title, description });
            } catch (error) {
                console.error('Error fetching work item:', error);
                setError('Failed to fetch data');
            }
        };

        fetchWorkItem();
    }, [id]);

    const handleChange = (e) => {
        if (e.target.type === 'file') {
            setFormData({ ...formData, image: e.target.files[0] });
        } else {
            setFormData({ ...formData, [e.target.name]: e.target.value });
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError(null);

        try {
            const formDataWithFile = new FormData();
            formDataWithFile.append('image', formData.image);
            formDataWithFile.append('title', formData.title);
            formDataWithFile.append('description', formData.description);

            await axios.put(`http://localhost:5000/work/${id}`, formDataWithFile, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            });
            setSuccess(true);
            setFormData(initialFormData); // Reset form data
        } catch (error) {
            setError('Failed to update the work');
        } finally {
            setLoading(false);
        }
    };

    return (
        <>
            <NavDash />
            <div className=" mt-5 pt-4 mb-5 pb-4">
                <div className="bg-light py-3 px-3">
                    <div className="container d-flex justify-content-between ">
                        <h5 className='mb-0'>Edit Work</h5>
                        <Link to='/work'  className="btn btn-warning btn-sm">All Works</Link >
                    </div>
                </div>
                <div className="col-lg-6 mx-auto bg-success-subtle p-3 p-md-5 mt-4">
                    <form onSubmit={handleSubmit}>
                        <h4>Edit Work</h4>
                        <div className='mb-3'>
                            <label htmlFor="image">Image:</label>
                            {formData.image && typeof formData.image === 'string' && (
                                <div>
                                    <img
                                        src={`/homeimages/${formData.image}`}
                                        alt="Current Work"
                                        style={{ width: '50px', height: '50px', objectFit: 'cover', marginBottom: '10px' }}
                                    />
                                </div>
                            )}
                            <input className='form-control' type="file" id="image" name="image" onChange={handleChange} accept="image/*" />
                        </div>
                        <div className='mb-3'>
                            <label htmlFor="title">Title:</label>
                            <input className='form-control' type="text" id="title" name="title" value={formData.title} onChange={handleChange} required />
                        </div>
                        <div className='mb-3'>
                            <label htmlFor="description">Description:</label>
                            <input className='form-control' type='text' id="description" name="description" value={formData.description} onChange={handleChange} required />
                        </div>
                        <button type="submit" className="btn btn-success rounded-0 mt-3" disabled={loading}>
                            {loading ? 'Updating...' : 'Update'}
                        </button>
                        {success && <p className="text-success mt-3">Work updated successfully!</p>}
                        {error && <p className="text-danger mt-3">{error}</p>}
                    </form>
                </div>
            </div>

            <DashFoot />
        </>
    );
};

export default EditWork;
